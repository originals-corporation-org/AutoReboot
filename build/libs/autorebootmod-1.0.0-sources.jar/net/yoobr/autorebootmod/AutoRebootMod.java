package net.yoobr.autorebootmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.Path;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AutoRebootMod implements ModInitializer {

	private boolean rebootPending = false;
	private int rebootTicks = 0;
	private long ticksSinceStart = 0;
	private String lastTriggeredTime = "";

	// Настройки из конфига
	private String currentLang = "ru_ru";
	private String rebootMode = "Manual"; // Manual, Interval, Scheduled
	private int rebootSeconds = 15;
	private int intervalMinutes = 240;
	private final List<String> scheduleTimes = new ArrayList<>();
	private String startupScript = "start.bat";
	private int scriptDelay = 2;

	private final Map<String, JsonObject> allTranslations = new HashMap<>();

	@Override
	public void onInitialize() {
		loadAllConfigs();

		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			dispatcher.register(class_2170.method_9247("reboot")
					.executes(context -> {
						if (!context.getSource().method_9259(4)) {
							context.getSource().method_9213(class_2561.method_43470(getMsg("no_permission", 0)));
							return 0;
						}
						startRebootProcess(context.getSource().method_9211());
						return 1;
					}));
		});

		ServerTickEvents.END_SERVER_TICK.register(this::onTick);
	}

	private void startRebootProcess(MinecraftServer server) {
		if (rebootPending) return;
		rebootPending = true;
		rebootTicks = rebootSeconds * 20;
		server.method_3760().method_43514(
				class_2561.method_43470(getMsg("start_announcement", rebootSeconds)), false
		);
	}

	private String getMsg(String key, int value) {
		JsonObject langData = allTranslations.get(currentLang);
		if (langData != null && langData.has(key)) {
			return langData.get(key).getAsString().replace("%s", String.valueOf(value));
		}
		return "§c[Missing: " + key + "]";
	}

	private void executeStartupScript() {
		try {
			File scriptFile = new File(startupScript);
			if (!scriptFile.exists()) return;
			if (System.getProperty("os.name").toLowerCase().contains("win")) {
				Runtime.getRuntime().exec("cmd /c start " + startupScript);
			} else {
				Runtime.getRuntime().exec("sh ./" + startupScript);
			}
		} catch (Exception e) { e.printStackTrace(); }
	}

	private void loadAllConfigs() {
		try {
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			Path configDirPath = FabricLoader.getInstance().getConfigDir().resolve("autorebootmod");
			File configDir = configDirPath.toFile();
			if (!configDir.exists()) configDir.mkdirs();

			File mainConfigFile = new File(configDir, "autorebootmod.json");
			if (mainConfigFile.exists()) {
				JsonObject mainJson = gson.fromJson(new FileReader(mainConfigFile), JsonObject.class);
				currentLang = mainJson.get("language").getAsString();
				rebootMode = mainJson.get("reboot_mode").getAsString();
				rebootSeconds = mainJson.get("reboot_seconds").getAsInt();
				intervalMinutes = mainJson.get("interval_minutes").getAsInt();
				startupScript = mainJson.get("startup_script").getAsString();
				scriptDelay = mainJson.get("script_delay").getAsInt();

				scheduleTimes.clear();
				JsonArray times = mainJson.getAsJsonArray("schedule_times");
				for (int i = 0; i < times.size(); i++) {
					scheduleTimes.add(times.get(i).getAsString());
				}
			} else {
				JsonObject mainJson = new JsonObject();
				mainJson.addProperty("language", "ru_ru");
				mainJson.addProperty("reboot_mode", "Manual");
				mainJson.addProperty("reboot_seconds", 15);
				mainJson.addProperty("interval_minutes", 240);
				JsonArray defaultTimes = new JsonArray();
				defaultTimes.add("12:00"); defaultTimes.add("16:00"); defaultTimes.add("00:00");
				mainJson.add("schedule_times", defaultTimes);
				mainJson.addProperty("startup_script", "start.bat");
				mainJson.addProperty("script_delay", 2);
				try (FileWriter writer = new FileWriter(mainConfigFile)) { gson.toJson(mainJson, writer); }
				loadAllConfigs(); // Перезагружаем для заполнения переменных
			}

			File[] files = configDir.listFiles((dir, name) -> name.endsWith(".json") && !name.equals("autorebootmod.json"));
			if (files != null) {
				for (File file : files) {
					allTranslations.put(file.getName().replace(".json", ""), gson.fromJson(new FileReader(file), JsonObject.class));
				}
			}
		} catch (Exception e) { e.printStackTrace(); }
	}

	private void onTick(MinecraftServer server) {
		ticksSinceStart++;

		// Логика автоматических режимов
		if (!rebootPending) {
			if (rebootMode.equalsIgnoreCase("Interval")) {
				if (ticksSinceStart >= (long) intervalMinutes * 60 * 20) {
					startRebootProcess(server);
				}
			} else if (rebootMode.equalsIgnoreCase("Scheduled")) {
				String currentTime = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
				if (scheduleTimes.contains(currentTime) && !currentTime.equals(lastTriggeredTime)) {
					lastTriggeredTime = currentTime;
					startRebootProcess(server);
				}
			}
		}

		if (!rebootPending) return;
		rebootTicks--;

		if (rebootTicks > 0) {
			if (rebootTicks % 20 == 0) {
				int secondsLeft = rebootTicks / 20;
				if (secondsLeft % 30 == 0 || secondsLeft == 15 || secondsLeft == 10 || secondsLeft <= 5) {
					server.method_3760().method_43514(class_2561.method_43470(getMsg("countdown_prefix", secondsLeft)), false);
				}
			}
		} else if (rebootTicks == 0) {
			class_2561 reason = class_2561.method_43470(getMsg("kick_reason", 0));
			for (class_3222 player : new ArrayList<>(server.method_3760().method_14571())) {
				player.field_13987.method_14367(reason);
			}
		} else if (rebootTicks <= -(scriptDelay * 20)) {
			rebootPending = false;
			executeStartupScript();
			server.method_3747(false);
		}
	}
}